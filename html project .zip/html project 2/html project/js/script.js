// Function to change the header background color when the user scrolls down
function changeHeaderColorOnScroll() {
    const header = document.querySelector('header');
  
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        header.style.backgroundColor = '#555';
      } else {
        header.style.backgroundColor = '#333';
      }
    });
  }
  
  // Function to show an alert when the user clicks on the "Contact Us" link in the footer
  function showAlertOnContactLinkClick() {
    const contactLink = document.querySelector('footer a');
  
    contactLink.addEventListener('click', (event) => {
      event.preventDefault();
      alert('Thank you for your interest! To contact us, please use the information provided on the Contact page.');
    });
  }
  
  // Function to display a message when the user submits the contact form
  function handleContactFormSubmission() {
    const contactForm = document.querySelector('form');
  
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get('name');
      alert(`Thank you, ${name}! Your message has been sent.`);
      contactForm.reset();
    });
  }
  
  // Call the functions to enable their functionality
  changeHeaderColorOnScroll();
  showAlertOnContactLinkClick();
  handleContactFormSubmission();
  